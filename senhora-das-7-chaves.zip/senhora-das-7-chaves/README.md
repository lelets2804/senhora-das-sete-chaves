# Senhora das 7 Chaves — site

Site profissional de cartomancia (Baralho Cigano). React + Vite, 3D com three.js / react-three-fiber, animações com framer-motion.

## Rodar
    npm install
    npm run dev

## Onde trocar o conteúdo provisório
- Consultas, preços e depoimentos: `src/data/consultas.js`
- Texto "Quem guarda as chaves": `src/components/Home.jsx` (função `Senhora`)
- Conselhos da lua: `src/components/lua.js`
- Imagens das cartas: coloque `01.jpg` … `36.jpg` em `public/cartas/` e mude `USAR_IMAGENS` para `true` em `src/data/cartas.js`.
  Elas aparecem automaticamente no 3D da abertura, no leque, nas consultas (e depois nas leituras do consulente).

## Páginas
- `/` página inicial · `/agendar` agendamento + pagamento · `/entrar` login e cadastro
- `/minha-area` área do consulente (próximas consultas, leituras, anotações, conta)
- `/minha-area/consulta/:id` Sala de Consulta (chat + vídeo) e a leitura recebida
- `/painel` painel da cartomante (agenda, horários, bloqueios, consultas e preços, envio das leituras)

## Modo demonstração x real
Sem o arquivo `.env`, tudo roda no navegador com pagamento simulado.
Login da cartomante na demonstração: `senhora@demo.com` / `demo`.
Os e-mails que seriam enviados aparecem em `/demo/emails`.
Para ligar Supabase + Mercado Pago, siga **CONFIGURAR.md**.
