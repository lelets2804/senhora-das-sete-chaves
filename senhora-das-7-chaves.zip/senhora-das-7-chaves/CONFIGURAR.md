# Como ligar o site de verdade (Supabase + Mercado Pago)

Sem configurar nada, o site roda em **modo demonstração** (dados só no navegador, pagamento simulado).
Siga os passos abaixo uma única vez.

## 1. Supabase (login, banco de dados e arquivos)
1. Crie uma conta em supabase.com e um projeto novo (região: São Paulo).
2. Menu **SQL Editor** → cole todo o conteúdo de `supabase/migrations/001_inicial.sql` → **Run**.
3. Menu **Project Settings → API**: copie a *Project URL* e a chave *anon public*.
4. Na pasta do projeto, copie `.env.example` para `.env` e cole os dois valores.
5. Menu **Authentication → URL Configuration**: em *Site URL* coloque o endereço do site (ex.: `https://senhoradas7chaves.com.br`).
6. (Recomendado) **Authentication → Emails**: traduza os e-mails de confirmação e de nova senha para português.

## 2. Mercado Pago (Pix e cartão)
1. Entre em mercadopago.com.br/developers com a conta da cartomante → **Suas integrações → Criar aplicação** (tipo: Checkout Pro).
2. Em **Credenciais de produção**, copie o *Access Token* (começa com `APP_USR-`).
   Para testar sem dinheiro real, use antes as **credenciais de teste**.

## 3. Publicar as funções de pagamento
Instale a Supabase CLI (supabase.com/docs/guides/cli) e, na pasta do projeto:

    supabase login
    supabase link --project-ref SEU-PROJETO
    supabase secrets set MP_ACCESS_TOKEN=APP_USR-... SITE_URL=https://endereco-do-site
    supabase functions deploy criar-pagamento
    supabase functions deploy webhook-mercadopago --no-verify-jwt

## 4. E-mails automáticos (Resend)
O site envia sozinho:
- **para o consulente:** consulta confirmada, pergunta recebida, leitura pronta, lembrete 24h antes e 1h antes;
- **para a cartomante:** nova consulta paga e lembrete 1h antes.

1. Crie uma conta grátis em resend.com (3.000 e-mails/mês).
2. Em **Domains → Add Domain**, adicione o domínio do site e copie os registros DNS que aparecem para o painel onde o domínio foi comprado (Registro.br, Hostinger…). Espere ficar “Verified”.
   (Sem domínio próprio, o Resend só envia para o e-mail da própria conta — serve só para teste.)
3. Em **API Keys → Create API Key**, copie a chave (começa com `re_`).
4. Cadastre os segredos (invente uma senha qualquer para o CRON_SECRET):

       supabase secrets set RESEND_API_KEY=re_... EMAIL_REMETENTE="Senhora das 7 Chaves <contato@seudominio.com.br>" EMAIL_CARTOMANTE=email-dela@gmail.com CRON_SECRET=uma-senha-longa-qualquer

5. Publique as funções de e-mail:

       supabase functions deploy notificar-leitura
       supabase functions deploy lembretes --no-verify-jwt
       supabase functions deploy webhook-mercadopago --no-verify-jwt

6. Abra `supabase/migrations/002_emails.sql`, troque `SEU-PROJETO` e `SEU-SEGREDO` (o mesmo CRON_SECRET) e rode no **SQL Editor**. Isso liga os lembretes automáticos a cada 15 minutos.

### E-mails de cadastro e de nova senha (do próprio Supabase)
1. **Authentication → Emails → SMTP Settings**: ative o SMTP personalizado com os dados do Resend
   (host `smtp.resend.com`, porta `465`, usuário `resend`, senha = a chave `re_...`, remetente = o mesmo e-mail de cima).
   Sem isso, o Supabase só envia poucos e-mails por hora.
2. **Authentication → Emails → Templates**: cole o conteúdo dos arquivos da pasta `supabase/templates/`:
   - *Confirm signup* → `confirmar-cadastro.html` (assunto: “Confirme seu e-mail · Senhora das 7 Chaves”)
   - *Reset password* → `recuperar-senha.html` (assunto: “Criar nova senha · Senhora das 7 Chaves”)
   - *Change email address* → `trocar-email.html` (assunto: “Confirme seu novo e-mail”)

## 5. Tornar a cartomante administradora
1. Ela cria a conta normalmente pelo site (“Criar conta”).
2. No **SQL Editor** do Supabase rode (com o e-mail dela):

       update public.profiles set papel = 'admin' where email = 'EMAIL-DELA@exemplo.com';

3. Ao entrar de novo, aparece o link **Painel** no topo.

## 6. Colocar o site no ar (Vercel, gratuito)
1. Suba o projeto para o GitHub e importe em vercel.com.
2. Em **Settings → Environment Variables** adicione `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.
3. Conecte o domínio próprio em **Settings → Domains**.

## Observações
- Uma reserva não paga segura o horário por 30 minutos; depois o horário volta a ficar livre.
- Se, por azar, duas pessoas pagarem o mesmo horário no mesmo segundo, a segunda aparece no painel como
  “Conflito de horário” para a cartomante remarcar ou estornar (o estorno é feito no painel do Mercado Pago).
- Vídeo: cada consulta ao vivo tem uma sala automática do Jitsi Meet (grátis, abre em nova aba).
  A cartomante pode trocar pelo link que preferir (Google Meet, Zoom…) na página da consulta.
- Horários seguem o horário de Brasília.
- No modo demonstração, os e-mails aparecem na página `/demo/emails` em vez de serem enviados.
